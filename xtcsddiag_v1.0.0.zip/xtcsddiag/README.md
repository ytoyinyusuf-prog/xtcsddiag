# xtcsddiag

Residual and design diagnostics for heterogeneous panels with cross-sectional dependence (Stata 14+).

* `xtcsddiag` tests serial correlation, heteroskedasticity, normality and parameter stability unit by unit on CCE, mean-group or two-way fixed-effects residuals, with exact Monte Carlo unit p-values combined across units (Fisher, inverse normal), and reports the CD and CDw tests.
* `xtcdmax` tests cross-sectional independence with long-run standardized CD, sum, max-type and combined tests that allow for serial correlation.
* `xtcollin` computes VIFs, condition indices and variance-decomposition proportions for the within, two-way, first-difference, random-effects, between and CCE designs, pooled and unit by unit.

## Installation

```
net install xtcsddiag, from("folder or URL containing xtcsddiag.pkg")
```

## Example

```
use xtcsddiag_apec, clear
xtset id year
generate lnEF = ln(EF)
generate NET2 = NET^2
xtcsddiag lnEF NET NET2 GLB, seed(20261025)
xtcdmax lnEF NET NET2 GLB
xtcollin NET NET2 GLB, transform(cce) ccevars(lnEF NET NET2 GLB) units
```

Author: Yusuf Toyin Yusuf, Kwara State University (yusuf.yusuf@kwasu.edu.ng). License: MIT.
